package com.umlet.element.base.activity;

public enum Direction {
	TOP, LEFT, RIGHT, BOTTOM;
}
